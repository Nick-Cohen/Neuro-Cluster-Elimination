"""
Compare NeuroBE paper results with our sanity check NeuroBE run.

Paper data: NCE-Data/NeuroBE_paper_results.csv
Our data:   nbe_sanity_check benchmark results (nbe_full_epochs.txt)

Overlapping problems: pedigree13, grid40x40.f10, grid20x20.f10, rbm_20
Ground truth (refZ) taken from paper CSV for error computation.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

# ---------------------------------------------------------------------------
# Our sanity check results in summary.csv format
# Source: notebooks/March-2026/claude_experiments/nbe_eval_results/nbe_full_epochs.txt
# ---------------------------------------------------------------------------
our_results = pd.DataFrame([
    {
        'problem_name': 'pedigree13',
        'width': 33,
        'num_vars': 888,
        'log_Z_ground_truth': None,  # will fill from paper refZ
        'log_Z_hat': -31.764139,
        'num_trained': 0,
        'time': 35788.4,
        'num_samples': 'nbe,0.1',
        'architecture': 'nbe,3',
        'loss_fn': 'weighted_logspace_mse',
        'config_name': 'nbe_sanity_check',
    },
    {
        'problem_name': 'grid40x40.f10',
        'width': 55,
        'num_vars': 1600,
        'log_Z_ground_truth': None,
        'log_Z_hat': 5349.348633,
        'num_trained': 0,
        'time': 21950.5,
        'num_samples': 'nbe,0.35',
        'architecture': 'nbe,1',
        'loss_fn': 'weighted_logspace_mse',
        'config_name': 'nbe_sanity_check',
    },
    {
        'problem_name': 'grid20x20.f10',
        'width': 27,
        'num_vars': 400,
        'log_Z_ground_truth': None,
        'log_Z_hat': 1197.311035,
        'num_trained': 0,
        'time': 2864.0,
        'num_samples': 'nbe,0.35',
        'architecture': 'nbe,1',
        'loss_fn': 'weighted_logspace_mse',
        'config_name': 'nbe_sanity_check',
    },
    {
        'problem_name': 'rbm_20',
        'width': 21,
        'num_vars': 40,
        'log_Z_ground_truth': None,
        'log_Z_hat': 57.987244,
        'num_trained': 0,
        'time': 3240.5,
        'num_samples': 'nbe,0.1',
        'architecture': 'nbe,3',
        'loss_fn': 'weighted_logspace_mse',
        'config_name': 'nbe_sanity_check',
    },
])

# ---------------------------------------------------------------------------
# Name mapping: paper name -> our name
# ---------------------------------------------------------------------------
NAME_MAP = {
    'pedigree13':    'pedigree13',
    'grid4040f10':   'grid40x40.f10',
    'grid2020f10':   'grid20x20.f10',
    'rbm20':         'rbm_20',
}

# Row selectors for paper CSV (section, id)
ROW_SELECT = {
    'pedigree13':  ('i-bound=20', 1),
    'grid4040f10': ('i-bound=20', 1),
    'grid2020f10': ('i-bound=10', 4),
    'rbm20':       ('i-bound=20', 1),
}

# ---------------------------------------------------------------------------
# Load paper CSV
# ---------------------------------------------------------------------------
paper_csv = '/home/cohenn1/NCE/NCE-Data/NeuroBE_paper_results.csv'
paper_df = pd.read_csv(paper_csv)

# ---------------------------------------------------------------------------
# Build comparison data
# ---------------------------------------------------------------------------
rows = []
for paper_name, our_name in NAME_MAP.items():
    section, row_id = ROW_SELECT[paper_name]
    paper_row = paper_df[
        (paper_df['name'] == paper_name) &
        (paper_df['section'] == section) &
        (paper_df['id'] == row_id)
    ].iloc[0]

    ref_z = float(paper_row['refZ'])
    our_row = our_results[our_results['problem_name'] == our_name].iloc[0]
    our_logz = our_row['log_Z_hat']
    our_err = our_logz - ref_z
    our_abs_err = abs(our_err)

    # Fill in ground truth from paper
    our_results.loc[our_results['problem_name'] == our_name, 'log_Z_ground_truth'] = ref_z

    rows.append({
        'problem': our_name,
        'ref_z': ref_z,
        'num_vars': int(our_row['num_vars']),
        'width': int(our_row['width']),
        # Paper results
        'paper_nbe_avg_err': float(paper_row['NeuroBE_avg_error']),
        'paper_nbe_min_err': float(paper_row['NeuroBE_min_error']),
        'paper_nbe_time_h': float(paper_row['NeuroBE_time_h']),
        'paper_wmb_err': float(paper_row['WMB_error']),
        # Our results
        'our_log_Z_hat': our_logz,
        'our_err': our_err,
        'our_abs_err': our_abs_err,
        'our_num_trained': int(our_row['num_trained']),
        'our_time_s': float(our_row['time']),
        'our_time_h': float(our_row['time']) / 3600.0,
    })

# Complete summary.csv-style columns for our data
our_results['err'] = our_results.apply(
    lambda r: r['log_Z_hat'] - r['log_Z_ground_truth'] if r['log_Z_ground_truth'] is not None else None, axis=1)
our_results['abs_err'] = our_results['err'].abs()

comp = pd.DataFrame(rows)

# ---------------------------------------------------------------------------
# Print summary table
# ---------------------------------------------------------------------------
print("\n" + "=" * 120)
print("Comparison: Paper NeuroBE vs Our Sanity Check NeuroBE")
print("=" * 120)
fmt = "{:<18} {:>8} {:>6} {:>8} {:>12} {:>12} {:>10} {:>12} {:>10} {:>10}"
print(fmt.format(
    'Problem', 'refZ', '#vars', 'width',
    'Paper avg err', 'Paper min err', 'Paper time',
    'Our abs err', 'Our time', '#NN bkts'))
print("-" * 120)
for _, r in comp.iterrows():
    print(fmt.format(
        r['problem'],
        f"{r['ref_z']:.2f}",
        r['num_vars'],
        r['width'],
        f"{r['paper_nbe_avg_err']:.3f}",
        f"{r['paper_nbe_min_err']:.3f}",
        f"{r['paper_nbe_time_h']:.2f}h",
        f"{r['our_abs_err']:.3f}",
        f"{r['our_time_h']:.2f}h",
        r['our_num_trained'],
    ))
print("-" * 120)

# Also save our results in summary.csv format
our_csv_path = os.path.join(os.path.dirname(__file__), 'sanity_check_results.csv')
our_results.to_csv(our_csv_path, index=False)
print(f"\nOur results saved in summary.csv format: {our_csv_path}")

# ---------------------------------------------------------------------------
# Figure: 2 subplots - errors (left) and times (right)
# ---------------------------------------------------------------------------
fig, (ax_err, ax_time) = plt.subplots(1, 2, figsize=(16, 7))

problems = comp['problem'].tolist()
n = len(problems)
x = np.arange(n)

# --- Error comparison (left) ---
bar_w = 0.22
colors = {'paper_avg': '#FF9800', 'paper_min': '#4CAF50', 'paper_wmb': '#90CAF9', 'ours': '#9C27B0'}

bars_wmb = ax_err.bar(x - 1.5 * bar_w, comp['paper_wmb_err'], bar_w,
                      label='Paper WMB', color=colors['paper_wmb'],
                      edgecolor='black', linewidth=0.5)
bars_avg = ax_err.bar(x - 0.5 * bar_w, comp['paper_nbe_avg_err'], bar_w,
                      label='Paper NeuroBE (avg)', color=colors['paper_avg'],
                      edgecolor='black', linewidth=0.5)
bars_min = ax_err.bar(x + 0.5 * bar_w, comp['paper_nbe_min_err'], bar_w,
                      label='Paper NeuroBE (min)', color=colors['paper_min'],
                      edgecolor='black', linewidth=0.5)
bars_ours = ax_err.bar(x + 1.5 * bar_w, comp['our_abs_err'], bar_w,
                       label='Our NeuroBE', color=colors['ours'],
                       edgecolor='black', linewidth=0.5)

# Value labels
for bars in [bars_wmb, bars_avg, bars_min, bars_ours]:
    for bar in bars:
        h = bar.get_height()
        if h > 0:
            ax_err.annotate(f'{h:.2f}',
                            xy=(bar.get_x() + bar.get_width() / 2, h),
                            xytext=(0, 2), textcoords='offset points',
                            ha='center', va='bottom', fontsize=7, rotation=90)

ax_err.set_yscale('log')
ax_err.set_ylabel('Absolute Error in log Z', fontsize=11)
ax_err.set_title('Error Comparison', fontsize=13, fontweight='bold')
ax_err.set_xticks(x)
ax_err.set_xticklabels(problems, rotation=25, ha='right', fontsize=9)
ax_err.legend(fontsize=8, loc='upper left')
ax_err.grid(axis='y', alpha=0.3)

# --- Time comparison (right) ---
bar_w_t = 0.3
bars_paper_t = ax_time.bar(x - bar_w_t / 2, comp['paper_nbe_time_h'], bar_w_t,
                           label='Paper NeuroBE', color='#FF9800',
                           edgecolor='black', linewidth=0.5)
bars_our_t = ax_time.bar(x + bar_w_t / 2, comp['our_time_h'], bar_w_t,
                         label='Our NeuroBE', color='#9C27B0',
                         edgecolor='black', linewidth=0.5)

for bars in [bars_paper_t, bars_our_t]:
    for bar in bars:
        h = bar.get_height()
        ax_time.annotate(f'{h:.1f}h',
                         xy=(bar.get_x() + bar.get_width() / 2, h),
                         xytext=(0, 2), textcoords='offset points',
                         ha='center', va='bottom', fontsize=8)

ax_time.set_ylabel('Time (hours)', fontsize=11)
ax_time.set_title('Training Time Comparison', fontsize=13, fontweight='bold')
ax_time.set_xticks(x)
ax_time.set_xticklabels(problems, rotation=25, ha='right', fontsize=9)
ax_time.legend(fontsize=9)
ax_time.grid(axis='y', alpha=0.3)

plt.suptitle('Paper NeuroBE vs Our NeuroBE Sanity Check', fontsize=14, fontweight='bold', y=1.02)
plt.tight_layout()

out_path = os.path.join(os.path.dirname(__file__), 'compare_paper_vs_sanity_check.png')
plt.savefig(out_path, dpi=150, bbox_inches='tight')
print(f"Saved chart: {out_path}")
plt.close()
